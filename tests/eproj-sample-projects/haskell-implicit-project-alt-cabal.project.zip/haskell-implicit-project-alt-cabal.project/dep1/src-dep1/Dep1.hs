----------------------------------------------------------------------------
-- |
-- Module      :  Dep1
-- Copyright   :  (c) Sergey Vinokurov 2022
-- License     :  Apache-2.0 (see LICENSE)
-- Maintainer  :  serg.foo@gmail.com
----------------------------------------------------------------------------

module Dep1
  ( dep1
  )
where

dep1 :: Int -> Int
dep1 x = x + 1
