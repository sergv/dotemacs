----------------------------------------------------------------------------
-- |
-- Module      :  Dep2
-- Copyright   :  (c) Sergey Vinokurov 2022
-- License     :  Apache-2.0 (see LICENSE)
-- Maintainer  :  serg.foo@gmail.com
----------------------------------------------------------------------------

module Dep2
  ( dep2
  )
where

import Dep1

dep2 :: Int -> Int
dep2 = dep1 . (+5)
