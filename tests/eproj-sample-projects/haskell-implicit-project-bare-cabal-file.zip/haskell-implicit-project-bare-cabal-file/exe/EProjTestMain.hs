-- |
-- Module:     EProjTestmain
-- Copyright:  (c) Sergey Vinokurov 2026
-- License:    Apache-2.0 (see LICENSE)
-- Maintainer: serg.foo@gmail.com

module EProjTestMain (main) where

import Data.Map.Strict (Map)
import Data.Text (Text)

import EProjTestLib

bar :: Map k String -> Map k Text
bar = fmap foo

main :: IO ()
main = do
  print $ bar ()
  pure ()
