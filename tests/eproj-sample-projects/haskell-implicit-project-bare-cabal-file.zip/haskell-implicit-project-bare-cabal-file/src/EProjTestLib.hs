-- |
-- Module:     EProjTestLib
-- Copyright:  (c) Sergey Vinokurov 2026
-- License:    Apache-2.0 (see LICENSE)
-- Maintainer: serg.foo@gmail.com

module EProjTestLib (foo) where

import Data.Text as T

foo :: String -> Text
foo = (\x -> x <> x) . T.pack
