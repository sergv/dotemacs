----------------------------------------------------------------------------
-- |
-- Module      :  MainMod
-- Copyright   :  (c) Sergey Vinokurov 2022
-- License     :  Apache-2.0 (see LICENSE)
-- Maintainer  :  serg.foo@gmail.com
----------------------------------------------------------------------------

module MainMod (mainFunc) where

import SubdepFoo
import Dep1
import Dep2

mainFunc :: Int -> Double -> Int
mainFunc x y = dep2 $ dep1 $ subdepFoo x y
