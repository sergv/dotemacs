----------------------------------------------------------------------------
-- |
-- Module      :  SubdepFoo
-- Copyright   :  (c) Sergey Vinokurov 2022
-- License     :  Apache-2.0 (see LICENSE)
-- Maintainer  :  serg.foo@gmail.com
----------------------------------------------------------------------------

module SubdepFoo
  ( subdepFoo
  ) where

subdepFoo :: a -> b -> a
subdepFoo a _ = a
