-- |
-- Module:     Bar.Baz
-- Copyright:  (c) Sergey Vinokurov 2025
-- License:    Apache-2.0 (see LICENSE)
-- Maintainer: serg.foo@gmail.com

module Bar.Baz (baz) where

baz :: a -> b
baz x = x
